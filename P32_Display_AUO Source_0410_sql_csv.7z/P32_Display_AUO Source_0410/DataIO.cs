﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace P32_UISDisplay_Ward
{
    class DataIO
    {

        private static void split_to_array_txt(string dline, Int32[] gdatat, int offset)
        {
            int i;
            string[] spld = dline.Split( new char[] { ' ' } );
            //foreach (string s in spld)
            for (i = 0; i < 9; i++)
            {
                gdatat[i] = (Int32)(Convert.ToInt32(spld[i]));
            }
        }
        public static void loadFile_txt(string str_file_name , Int32[] gdatat )
        {
            int i = 0;
            StreamReader objReader = new StreamReader( str_file_name );

            string sLine = "";
            sLine = objReader.ReadLine();
            while (sLine != null)
            {
                split_to_array_txt(sLine, gdatat,i);
                i += 9;
                sLine = objReader.ReadLine();
            }

            objReader.Close();
        }
        private static void split_to_array(string dline, Int32[] gdatat, int offset)
        {
            string[] spld = dline.Split( new char[] { ',' } );
            foreach (string s in spld)
            {
            //    Console.WriteLine(s);
                gdatat[offset] = (Int32)(Convert.ToInt32(s));
                offset++;
            }
        }
        public static void loadFile(string str_file_name , Int32[] gdatat )
        {
            int i = 0;
            StreamReader objReader = new StreamReader( str_file_name );

            string sLine = "";
            sLine = objReader.ReadLine();
            while (sLine != null)
            {
                split_to_array(sLine, gdatat,i);
                i += 10;
                sLine = objReader.ReadLine();
            }

            objReader.Close();
        }

        public static void saveFile(string str_file_name, short[] gdata)
        {
            string separator = "," ;
            string[] value_list = new string[320];
            StreamWriter objWriter = new StreamWriter(str_file_name);

            for (int j = 0; j < 240; j++)
            {
                for ( int i = 0 ; i < 320 ; i++ )
                {
                    value_list[ i ] = gdata[j * 320 + i].ToString();
                }
                string result = string.Join(separator, value_list, 0, 320);
                objWriter.WriteLine(result);
            }

            objWriter.Close();

        }
        public static void StartStringToFile(string str_file_name, string[] data)
        {
            string separator = "," ;

            StreamWriter objWriter = new StreamWriter(str_file_name);

            string result = string.Join(separator, data);
            objWriter.WriteLine(result);

            objWriter.Close();

        }

        public static void AddStringToFile(string str_file_name, string[] data)
        {
            string separator = "," ;
            //string[] value_list = new string[20];

            //StreamWriter objWriter = new StreamWriter(str_file_name);
            StreamWriter objWriter = new System.IO.StreamWriter( str_file_name, true );

            string result = string.Join(separator, data);
            objWriter.WriteLine(result);

            objWriter.Close();

        }

    }
}
