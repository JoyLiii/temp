﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P32_UISDisplay_Ward
{
    /// <summary>
    /// Data Layer類別 (命令資料建立、封裝)
    /// </summary>
    public class DataLayer
    {
        //      0     1     2     3     4     5     6     7
        //   +-----+-----+-----+-----+-----+-----+-----+-----+
        // 0 |                   Preamble                    |
        //   +-----+-----+-----+-----+-----+-----+-----+-----+
        // 1 |                     Type                      |
        //   +-----+-----+-----+-----+-----+-----+-----+-----+
        // 2 |                    Length                     |
        //   +-----+-----+-----+-----+-----+-----+-----+-----+
        // 3 |                    Command/CRC                |
        //   :                       :                       :
        //   +-----+-----+-----+-----+-----+-----+-----+-----+

        public const byte Preamble = 0x96;   // Frame璅
        private const int headerLength = 3;  // Data表頭長度

        private List<byte> dataBytes;        // data資料
        private List<byte> commandBytes;     // 命令資料

        private byte type;                   // 命令類型
        private int length;                  // 命令長度
        private byte[] command;              // 命令

        #region punlic 屬性

        /// <summary>
        /// 取得命令類型
        /// </summary>
        public byte Type
        {
            get { return this.type; }
        }

        /// <summary>
        /// 取得命令長度
        /// </summary>
        public int Length
        {
            get { return this.length; }
        }

        /// <summary>
        /// 取得命令
        /// </summary>
        public byte[] Command
        {
            get { return (byte[])this.command.Clone(); }
        }

        #endregion

        /// <summary>
        /// Data Layer建構
        /// </summary>
        /// <param name="type">命令類型</param>
        /// <param name="length">命令長度</param>
        /// <param name="command">命令</param>
        public DataLayer(byte type, int length, byte[] command)
        {
            this.dataBytes = new List<byte>();
            this.commandBytes = new List<byte>();

            this.commandBytes.AddRange(command);

            this.dataBytes.AddRange(new byte[headerLength]);
            this.dataBytes.AddRange(this.commandBytes);


            this.type = type;
            this.length = length + headerLength;

            this.dataBytes[0] = this.type;
            this.dataBytes[1] = (byte)this.length;

            this.command = (byte[])command.Clone();
        }

        #region public 方法

        /// <summary>
        /// 建立Data個體
        /// </summary>
        /// <param name="bytes">byte data</param>
        /// <returns>Data個體</returns>
        public static DataLayer CreateInstance(byte[] bytes)
        {
            if (bytes.Length > headerLength)
            {
                byte checkSum = bytes[3+bytes[2]];

                byte byte5 = StaticMethods.CheckSum(bytes, 0, 3+bytes[2]);

                if (bytes[0] == DataLayer.Preamble)// && checkSum == byte5)
                {
                    byte[] command = new byte[bytes.Length - headerLength];
                    Array.Copy(bytes, headerLength, command, 0, command.Length);
                    DataLayer data = new DataLayer(bytes[1], bytes[2], command);

                    return data;

                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }

        /// <summary>
        /// Data轉Byte陣列
        /// </summary>
        /// <returns>Byte陣列</returns>
        public byte[] ToByteArray()
        {
            return this.dataBytes.ToArray();
        }

        #endregion
    }
}
