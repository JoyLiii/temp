﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
using System.IO;
using System.Threading;


using System.Data.Odbc;
using System.Data.SqlClient;

namespace P32_UISDisplay_Ward
{
    public partial class Form1 : Form
    {
        private Byte[] tx;
        private Byte Display_Luck;
        private Byte serialPortOpenStatus;
        private SerialPort serialPort;
        private string User_ID;
        private int U_flag;
        private int U_warm_flag;
        private string now_time;
        //private string connectionString_odb = "dsn=L6AH;uid=L6ACEL_AP;pwd=L6ACEL$AP";
        private string connectionString_odb = "dsn=TCDOORS.CORPNET.AUO.COM;uid=L6ACEL_AP;pwd=L6ACEL$AP";
        private string connectionString_sql = "Database=BEOL;Server=TW100039277\\PC05SQLSERVER;UID=sa;PWD=9ol.)P:?;";
        String user_name, user_workid;
        float def;
        int time,time3;

        private Int32[] TempBufData = new Int32[40];
    


        delegate void Display(Byte[] buffer);

        public Form1()
        {
            InitializeComponent();
            timer2.Stop();
            

            string[] comports = SerialPort.GetPortNames();
            for (int i = 0; i < comports.Length; i++)
                this.comboBox1.Items.Add(comports[i]);
            if (comports.Length >= 1)
            {
                this.comboBox1.SelectedItem = 0;
                this.comboBox1.Text = comports[2];
            }
            this.cB_bundrate.SelectedItem = 1;
            this.cB_bundrate.Text = "9600";
            //this.cB_bundrate.Text = "115200";
            this.tx = new byte[1024];
            this.serialPortOpenStatus = 0;
     
            this.toolStripStatusLabel1.Text = "UIS";
   
            this.timer1.Enabled=true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Focus();
            label3.Text = "請刷卡，謝謝。";
            if (serialPortOpenStatus == 1)
            {
                this.serialPort.Close();
                comboBox1.Enabled = true;
                //txtSensorEnable.Text = "";
                btn_Open_Com_Port.Text = "開啟";
                serialPortOpenStatus = 0;
                Display_Luck = 0;
                textBox2.Enabled = true;

            }
            else
            {
                textBox2.Enabled = false;
                this.serialPort = new SerialPort(this.comboBox1.SelectedItem.ToString());
                if(cB_bundrate.Text=="9600"){
                    this.serialPort.BaudRate = 9600;
                }
                else if (cB_bundrate.Text == "115200")
                {
                    this.serialPort.BaudRate = 115200;
                }

                this.serialPort.DataReceived += serialPort_DataReceived;
                this.serialPort.Close();

                if (!this.serialPort.IsOpen)
                {
                    try
                    {
                        this.serialPort.Open();
                        serialPortOpenStatus = 1;
                        comboBox1.Enabled = false;
                        btn_Open_Com_Port.Text = "關閉";
              
                    }
                    catch (UnauthorizedAccessException e1)
                    {
                        //MessageBox.Show("無法開啟 COM Port");
                        MessageBox.Show("無法開啟 COM Port", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                     }


                }
            }
        }
    
        void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (e.EventType == SerialData.Chars)
            {
                List<byte> rxList = Get_Uart();
                if (rxList != null)
                {
                    Byte[] buffer = rxList.ToArray();
             
                    DataLayer data = DataLayer.CreateInstance(buffer);
                    switch (data.Type)
                    {
                  
                             
                        case 0x62:
                            Display S62 = new Display(ShowTEMP);
                            this.Invoke(S62, new Object[] { buffer });
                            break;
                                        
                     
                    
                    }
                }
            }

        }
    
   
      
      
        private void ShowTEMPtoUI_D(Int32[] buffer_Temperature)
        {
            Byte Cnt = 0;
            Byte i;
            Byte Max_iterm;
            Int32 Max_Value;
            float f_TP;
            string tmp;
            string str;

            if (Display_Luck == 0)
            {

                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");


                //sensor1
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");

                //sensor2
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");

                //sensor3
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");

                //sensor4
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");
                tmp = buffer_Temperature[Cnt++].ToString("D4");


                Max_Value = buffer_Temperature[4];
                Max_iterm = 4;
                for (i = 4; i < Cnt; i++)
                {
                    if (buffer_Temperature[i] > Max_Value)
                    {
                        Max_Value = buffer_Temperature[i];
                        Max_iterm = i;
                    }
                }

                lblS1.Text = "";
                def = float.Parse(textBox2.Text);
                f_TP = (float)buffer_Temperature[Max_iterm] / 100;
                f_TP = f_TP + def;
                //lblS1.Text = buffer_Temperature[Max_iterm].ToString("D4");
                lblS1.Text = f_TP.ToString("f2");
                if (U_flag == 1 && U_warm_flag == 0)
                {

                    if ((f_TP >= 33.00) && (f_TP <= 37.3))
                    {
                        str = "";
                        write_db(f_TP,str);
                        //write_csv(f_TP, str);
                        reset();
                        
                    }
                    else if (f_TP > 37.3)
                    {
                        if (user_name == "")
                        {
                            U_warm_flag = 1;
                            label3.Text = " 使用者 : " + "\t" + User_ID + "\t" + "體溫過高，請再量測一次。";
                        }
                        else {
                            U_warm_flag = 1;
                            label3.Text = " 使用者 : " + "\t" + user_name + "\t" + "體溫過高，請再量測一次。";
                        }

                    }
                } else if (U_flag == 1 && U_warm_flag == 1) {
                    if ((f_TP >= 33.00) && (f_TP <= 37.3))
                    {
                        str = "";
                        write_db(f_TP,str);
                        //write_csv(f_TP, str);
                        reset();


                    } else if (f_TP > 37.3) {
                        str = "兩次體溫過高人工量測";
                        write_db(f_TP, str);
                        //write_csv(f_TP, str);
                       
                        textBox1.Text = "";
                        label3.Text = "體溫過高，請人工量測。";
                        timer3.Start();

                    }
                }
            }
        }
     
     

        private void ShowTEMP(Byte[] buffer)
        {
            Int32[] BufData = new Int32[40];
            Byte Cnt = 0;
        

            BufData[Cnt++] = (int)buffer[4] * 256 + (int)buffer[3];
            BufData[Cnt++] = (int)buffer[6] * 256 + (int)buffer[5];
            BufData[Cnt++] = (int)buffer[8] * 256 + (int)buffer[7];
            BufData[Cnt++] = (int)buffer[10] * 256 + (int)buffer[9];

            //sensor1
            BufData[Cnt++] = (int)buffer[12] * 256 + (int)buffer[11];
            BufData[Cnt++] = (int)buffer[14] * 256 + (int)buffer[13];
            BufData[Cnt++] = (int)buffer[16] * 256 + (int)buffer[15];
            BufData[Cnt++] = (int)buffer[18] * 256 + (int)buffer[17];
            BufData[Cnt++] = (int)buffer[20] * 256 + (int)buffer[19];
            BufData[Cnt++] = (int)buffer[22] * 256 + (int)buffer[21];
            BufData[Cnt++] = (int)buffer[24] * 256 + (int)buffer[23];
            BufData[Cnt++] = (int)buffer[26] * 256 + (int)buffer[25];

            //sensor2
            BufData[Cnt++] = (int)buffer[28] * 256 + (int)buffer[27];
            BufData[Cnt++] = (int)buffer[30] * 256 + (int)buffer[29];
            BufData[Cnt++] = (int)buffer[32] * 256 + (int)buffer[31];
            BufData[Cnt++] = (int)buffer[34] * 256 + (int)buffer[33];
            BufData[Cnt++] = (int)buffer[36] * 256 + (int)buffer[35];
            BufData[Cnt++] = (int)buffer[38] * 256 + (int)buffer[37];
            BufData[Cnt++] = (int)buffer[40] * 256 + (int)buffer[39];
            BufData[Cnt++] = (int)buffer[42] * 256 + (int)buffer[41];

            //sensor3
            BufData[Cnt++] = (int)buffer[44] * 256 + (int)buffer[43];
            BufData[Cnt++] = (int)buffer[46] * 256 + (int)buffer[45];
            BufData[Cnt++] = (int)buffer[48] * 256 + (int)buffer[47];
            BufData[Cnt++] = (int)buffer[50] * 256 + (int)buffer[49];
            BufData[Cnt++] = (int)buffer[52] * 256 + (int)buffer[51];
            BufData[Cnt++] = (int)buffer[54] * 256 + (int)buffer[53];
            BufData[Cnt++] = (int)buffer[56] * 256 + (int)buffer[55];
            BufData[Cnt++] = (int)buffer[58] * 256 + (int)buffer[57];

            //sensor4
            BufData[Cnt++] = (int)buffer[60] * 256 + (int)buffer[59];
            BufData[Cnt++] = (int)buffer[62] * 256 + (int)buffer[61];
            BufData[Cnt++] = (int)buffer[64] * 256 + (int)buffer[63];
            BufData[Cnt++] = (int)buffer[66] * 256 + (int)buffer[65];
            BufData[Cnt++] = (int)buffer[68] * 256 + (int)buffer[67];
            BufData[Cnt++] = (int)buffer[70] * 256 + (int)buffer[69];
            BufData[Cnt++] = (int)buffer[72] * 256 + (int)buffer[71];
            BufData[Cnt++] = (int)buffer[74] * 256 + (int)buffer[73];

            ShowTEMPtoUI_D(BufData);

        }
    
              
      
        private List<byte> Get_Uart()
        {
            List<byte> rx = new List<byte>();
            int uartstate = 0;

            while (rx.Count != -1)
            {
                try
                {
                    System.Threading.Thread.Sleep(10);

                    if (serialPort.BytesToRead > 0)
                    {
                        byte[] rx_tmp = new byte[serialPort.BytesToRead];
                        if (rx_tmp.Length > 2 && uartstate == 0)
                        {
                            byte[] rx_tmp2 = new byte[1];
                            serialPort.Read(rx_tmp2, 0, 1);

                            if (rx_tmp2[0] == 0x96)
                            {
                                rx.Add(rx_tmp2[0]);

                                while (rx.Count < rx_tmp.Length)
                                {
                                    serialPort.Read(rx_tmp2, 0, 1);
                                    rx.Add(rx_tmp2[0]);

                                    if (rx.Count > 3 && rx.Count == rx[2] + 4)
                                    {
                                        rx_tmp = rx_tmp2 = null;
                                        return rx;
                                    }
                                }
                                uartstate = 1;
                            }
                        }
                        else if (uartstate == 1 && rx_tmp.Length > 0)
                        {

                            byte[] rx_tmp2 = new byte[1];
                            for (int i = 0; i < rx_tmp.Length; i++)
                            {
                                serialPort.Read(rx_tmp2, 0, 1);
                                rx.Add(rx_tmp2[0]);

                                if (rx.Count > 3 && rx.Count == rx[2] + 4)
                                {
                                    rx_tmp = rx_tmp2 = null;
                                    uartstate = 0;
                                    return rx;
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {

                }
            }

            if (rx.Count > 3 && rx.Count == rx[2] + 4)
            {
                uartstate = 0;
                return rx;
            }
            else
            {
                return null;
            }

        }
        private void Send(byte[] tx, int offset, int count)
        {
            //this.serialPort.DiscardInBuffer();
            //this.serialPort.DiscardOutBuffer();
            //string callerName = this.GetType().Name + "." + MethodBase.GetCurrentMethod().Name;

            try
            {
                this.serialPort.Write(tx, offset, count);
            }
            catch (UnauthorizedAccessException e)
            {
                //TraceLog.TraceEvent(TraceEventType.Warning, 10000, callerName, e);
                //this.frameTimer.Stop();
                //MessageBox.Show(Properties.Resources.S00052);
            }
            catch (InvalidOperationException ex)
            {
                //TraceLog.TraceEvent(TraceEventType.Warning, 10000, callerName, ex);
                //this.frameTimer.Stop();
                //MessageBox.Show(Properties.Resources.S00053);
            }
            catch (Exception exc)
            {
                //TraceLog.TraceEvent(TraceEventType.Warning, 10000, callerName, exc);
                //this.frameTimer.Stop();
                //MessageBox.Show(e.Message);
            }
        }
   
        private void UpdateCOMPortList()
        {
            string[] comports = SerialPort.GetPortNames();
            this.comboBox1.Items.Clear();
            for (int i = 0; i < comports.Length; i++)
                this.comboBox1.Items.Add(comports[i]);
            if (comports.Length >= 1)
            {
                this.comboBox1.SelectedItem = 0;
                this.comboBox1.Text = comports[2];
            }

        }

      

        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateCOMPortList();
        }



        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            time = 0;
            time3 = 0;

            if (e.KeyCode == Keys.Enter)
            {
                timer2.Start();
                user_name = "";
                user_workid = "";
                if (!(textBox1.Text == ""))
                {
                    User_ID = textBox1.Text;
                    odb_cnn();

                    textBox1.Enabled = false;
                    cB_bundrate.Enabled = false;
                    btn_Open_Com_Port.Enabled = false;
                    U_warm_flag = 0;
                    U_flag = 1;

                    if (user_name == "")
                    {
                        label3.Text = "使用者 : " + User_ID + " 請量測體溫" + "\r\r" + "下一位請稍後刷卡。";
                    }
                    else { 
                        label3.Text = "使用者 : " + user_name + " 請量測體溫" + "\r\r" + "下一位請稍後刷卡。";
                    }

                    
                }
                else if (textBox1.Text == "")
                {
                    textBox1.Enabled = true;
                    U_warm_flag = 0;
                    U_flag = 0;

                    label3.Text = "請刷卡，謝謝。";
                    
                }

            }
        }

        private void odb_cnn() 
        {

            OdbcConnection con = new OdbcConnection(connectionString_odb);
            OdbcCommand cmd = new OdbcCommand("SELECT WORKID,HIDCARD,NAME FROM doorctl.t_entrant WHERE HIDCARD='" + User_ID + "'", con);
            con.Open();
            OdbcDataReader odr = cmd.ExecuteReader();

            while (odr.Read())
            {
                user_name = odr["NAME"].ToString();
                user_workid = odr["WORKID"].ToString();

            }
            odr.Close();
            cmd.Dispose();
            con.Close();  

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            time3++;

            /*停0.5秒*/
            if (time3 == 50)
            {
                timer3.Stop();
                time3 = 0;
                
                reset();


            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            time++;
            label5.Text = time.ToString();

            /*停20秒*/
            if (time == 200)
            {

                label5.Text = "time up";
                reset();
                
            }

        }

        private void reset()
        {
            label3.Text = "下一位請刷卡";
            textBox1.Text = "";
            User_ID = "";
            user_name = "";
            U_flag = 0;
            U_warm_flag = 0;
            btn_Open_Com_Port.Enabled = true;
            cB_bundrate.Enabled = true;
            textBox1.Enabled = true;
            textBox1.Focus();
            timer2.Stop();
            time = 0; 
        }

        private void write_db(float tempature,string note)
        {
            if (user_name == "")
            {
                now_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                SqlConnection con = new SqlConnection(connectionString_sql);
                SqlCommand cmd = new SqlCommand("INSERT INTO AUO_TEMP2 VALUES ('" + User_ID + "','查無資料庫','" + tempature + "','" + now_time + "','" + note + "')", con);
                con.Open();
                SqlDataReader odr = cmd.ExecuteReader();

                odr.Close();
                cmd.Dispose();
                con.Close();
            }
            else
            {
                now_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                SqlConnection con = new SqlConnection(connectionString_sql);
                SqlCommand cmd = new SqlCommand("INSERT INTO AUO_TEMP2 VALUES ('" + user_workid + "','" + user_name + "','" + tempature + "','" + now_time + "','" + note + "')", con);
                con.Open();
                SqlDataReader odr = cmd.ExecuteReader();

                odr.Close();
                cmd.Dispose();
                con.Close();

            }
        }

        private void write_csv(float tempature, string note)
        {
            if (user_name == "")
            {
                now_time = DateTime.Now.ToString("yyMMdd ");
                using (StreamWriter tw = new StreamWriter("C:/Users/JoyWCLi/Desktop/AUO_TEMP2/" + now_time + ".csv", true))  // 'true':新建或附加.
                {
                    now_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    tw.WriteLine(User_ID + ",'查無資料庫'," + tempature + "," + now_time + "," + note + "\r");
                    tw.Flush();
                    tw.Close();

                }
            }
            else {
                now_time = DateTime.Now.ToString("yyMMdd ");
                using (StreamWriter tw = new StreamWriter("C:/Users/JoyWCLi/Desktop/AUO_TEMP2/" + now_time + ".csv", true))  // 'true':新建或附加.
                {
                    now_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    tw.WriteLine(user_workid + "," + user_name + "," + tempature + "," + now_time + "," + note + "\r");
                    tw.Flush();
                    tw.Close();

                }
            }
        }


    }
}
