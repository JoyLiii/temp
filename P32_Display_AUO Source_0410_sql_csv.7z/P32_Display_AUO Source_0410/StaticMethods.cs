﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P32_UISDisplay_Ward
{
    public class StaticMethods
    {
        /// <summary>
        /// 計算所送封包之checksum
        /// </summary>
        public static byte CheckSum(byte[] bytes, int startIndex, int length)
        {
            UInt16 sum = 0;
            // The one’s complement sum is the arithmetic sum
            // of two of the words with the carry bit added
            // to the lowest bit position of the sum.
            for (int i = startIndex; i < length; i++)
            {
                sum += bytes[i];
                sum = (UInt16)(sum & 0xff);
            }
                sum += 1;
                sum = (UInt16)(sum & 0xff);

            return (byte)sum;
        }
    }
}
