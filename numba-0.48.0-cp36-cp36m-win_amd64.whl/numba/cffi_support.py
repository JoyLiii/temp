# -*- coding: utf-8 -*-
"""
Alias to numba.typing.cffi_utils for backward compatibility
"""
from __future__ import print_function, division, absolute_import
from numba.typing.cffi_utils import *
