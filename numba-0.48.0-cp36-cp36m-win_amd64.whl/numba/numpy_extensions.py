"""
NumPy extensions.
"""

from numba.targets.arraymath import cross2d


__all__ = [
    'cross2d'
]
